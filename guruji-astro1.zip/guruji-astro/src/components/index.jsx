import Header from "./header";
import Testimonial from "./user testimonial";
import Chackra from "./Chackra";
import UserReview from "./UserReview";
import Footer from "./Footer";

export { Header, Testimonial, Chackra, UserReview, Footer };
